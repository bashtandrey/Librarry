package com.bashtan.librarry.сonstants;


public class APPConstants {

    public static final String TITLE_LABEL = "River of Life";
    public static final String NAME_BD = "library";
    public static final String SETTING_KEY = "setting.key";

    public static final String TITLE_EXIT = "Exit";
    public static final String TEXT_EXIT = "Do you want to close the program?";
    public static final String FILE_ICON = "file:./image/ROF.jpg";
}
