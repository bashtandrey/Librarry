package com.bashtan.librarry.constructor;

public enum Gender {
    FEMALE, MALE, NULL
}
