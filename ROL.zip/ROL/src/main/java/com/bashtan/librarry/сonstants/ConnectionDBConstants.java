package com.bashtan.librarry.сonstants;

public class ConnectionDBConstants {
    public static final String CONNECTION_TRUE = "Connection to DB";
    public static final String CONNECTION_FALSE = "No connection to DB";
}
