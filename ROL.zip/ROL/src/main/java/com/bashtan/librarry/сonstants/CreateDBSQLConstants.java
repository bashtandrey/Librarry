package com.bashtan.librarry.сonstants;

public class CreateDBSQLConstants {
    public static final String CONNECT_TITLE = "Connection to the database";
    public static final String CONNECT_TEXT = "There is no connection to the database";
    public static final String CREATE_DB_TITLE = "Create database";
    public static final String CREATE_DB_TEXT = "Failed to create database";


}
