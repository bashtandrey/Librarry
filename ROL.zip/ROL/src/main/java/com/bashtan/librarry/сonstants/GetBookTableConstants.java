package com.bashtan.librarry.сonstants;

public class GetBookTableConstants {
    public static final String HUMAN_TableView_Null ="There are no readers with books";
    public static final String HUMAN_UNSELECT_BUTTON = "Unselect reader";
    public static final String BOOK_UNSELECT_BUTTON = "Unselect book";
    public static final String TITLE = "Accept the book";
    public static final String TEXT = "The book is accepted";
    public static final String OK_BUTTON = "OK";
    public static final String CANCEL_BUTTON = "Cancel";
}
