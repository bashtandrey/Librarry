package com.bashtan.chat.server;

public class WindowsChatServer {

}
