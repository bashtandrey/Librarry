package com.bashtan.chat.client;

import com.bashtan.chat.network.TCPConnection;
import com.bashtan.chat.network.TCPConnectionListener;
import com.bashtan.chat.server.ChatServer;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.io.IOException;

public class ClientWindowsController implements TCPConnectionListener {


    private TCPConnection connection;

    @FXML
    private TextArea a1;

    @FXML
    private TextField t1;

    @FXML
    private TextField t2;

    @FXML
    void onActionT2(ActionEvent event) {
    String msg = t2.getText();
    if(msg.equals("")) return;
    t2.setText("");
    connection.sendString(t1.getText() +": " + msg);
    }


    @FXML
    void initialize() {
        a1.setEditable(false);
        try {
            connection = new TCPConnection(this,"localhost",8189);
        } catch (IOException e) {
            printMsg("Connection exeption :" + e);
        }

    }

    @Override
    public void onConnectionReady(TCPConnection tcpConnection) {
    printMsg("Connection ready ...");
    }

    @Override
    public void onReceiveString(TCPConnection tcpConnection, String value) {
    printMsg(value);
    }

    @Override
    public void onDisconnect(TCPConnection tcpConnection) {
    printMsg("Connection close");
    }

    @Override
    public void onExeption(TCPConnection tcpConnection, Exception e) {
    printMsg("Connection exeption : "+ e);
    }

    private synchronized void printMsg(String msg){
        a1.appendText(msg +"\n");

    }
}
